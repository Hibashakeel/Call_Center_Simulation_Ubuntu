import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

# ===================== COLOR THEME =====================
BG      = "#0f1117"
CARD    = "#1a1d27"
CARD2   = "#22263a"
ACCENT  = "#6c63ff"
ACCENT2 = "#00c9a7"
RED     = "#ff6b6b"
AMBER   = "#ffd166"
TEXT    = "#e8e8f0"
MUTED   = "#7b7f9e"
WHITE   = "#ffffff"
GREEN   = "#06d6a0"
BORDER  = "#2e3250"

# ===================== CALLER CLASS =====================
class Caller:
    def __init__(self, name, burst_time):
        self.name            = name
        self.burst_time      = burst_time
        self.remaining_time  = burst_time
        self.arrival_time    = 0
        self.completion_time = 0
        self.turnaround_time = 0
        self.waiting_time    = 0
        self.finished        = False

# ===================== ROUND ROBIN ALGO =====================
def round_robin(callers, quantum):
    current_time = 0
    completed    = 0
    n            = len(callers)
    gantt        = []
    log_lines    = []

    while completed < n:
        all_idle = True
        for caller in callers:
            if caller.remaining_time > 0:
                all_idle = False
                serve = min(caller.remaining_time, quantum)
                start = current_time
                end   = current_time + serve
                log_lines.append(
                    f"  Time {start:>4} -> {end:>4}  |  Serving: {caller.name:<15}  |  Remaining: {caller.remaining_time - serve}"
                )
                gantt.append((caller.name, start, end))
                current_time          += serve
                caller.remaining_time -= serve
                if caller.remaining_time == 0 and not caller.finished:
                    caller.finished          = True
                    caller.completion_time   = current_time
                    caller.turnaround_time   = current_time - caller.arrival_time
                    caller.waiting_time      = caller.turnaround_time - caller.burst_time
                    completed               += 1
                    log_lines.append(f"           [DONE] {caller.name} - CALL COMPLETE")
        if all_idle:
            break

    return gantt, log_lines

# ===================== MAIN APP =====================
class CallCenterApp:
    def __init__(self, root):
        self.root         = root
        self.root.title("Call Center Simulation - Round Robin")
        self.root.geometry("1120x800")
        self.root.configure(bg=BG)
        self.root.resizable(True, True)

        self.callers_data = []
        self.last_results = None
        self.sim_count    = 0

        self._build_ui()

    # -------- UI STRUCTURE --------
    def _build_ui(self):
        # Header bar
        hdr = tk.Frame(self.root, bg=ACCENT, height=54)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="  Call Center Simulation",
                 font=("Courier New", 15, "bold"),
                 bg=ACCENT, fg=WHITE).pack(side="left", padx=20)
        tk.Label(hdr, text="Round Robin  |  Jinnah University for Women",
                 font=("Courier New", 9),
                 bg=ACCENT, fg="#d0cfff").pack(side="right", padx=20)

        # Body
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=12, pady=12)

        left  = tk.Frame(body, bg=BG, width=330)
        left.pack(side="left", fill="y", padx=(0,10))
        left.pack_propagate(False)

        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        self._build_left(left)
        self._build_right(right)

    def _section(self, parent, title, top=0):
        tk.Label(parent, text=title,
                 font=("Courier New", 9, "bold"),
                 bg=BG, fg=MUTED).pack(anchor="w", pady=(top, 3))
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x")
        return card

    # -------- LEFT PANEL --------
    def _build_left(self, parent):
        # Quantum
        qc = self._section(parent, "TIME QUANTUM")
        qf = tk.Frame(qc, bg=CARD)
        qf.pack(fill="x", padx=14, pady=12)
        tk.Label(qf, text="Quantum:", font=("Courier New", 11),
                 bg=CARD, fg=TEXT).pack(side="left")
        self.quantum_var = tk.StringVar(value="2")
        tk.Entry(qf, textvariable=self.quantum_var, width=6,
                 font=("Courier New", 13, "bold"),
                 bg=CARD2, fg=AMBER, insertbackground=AMBER,
                 relief="flat", justify="center").pack(side="right", ipady=4)

        # Add caller
        ac = self._section(parent, "ADD CALLER", top=10)
        af = tk.Frame(ac, bg=CARD)
        af.pack(fill="x", padx=14, pady=12)

        for row_i, (lbl, var_name, color) in enumerate([
            ("Name :", "name_var", WHITE),
            ("Burst :", "burst_var", AMBER),
        ]):
            tk.Label(af, text=lbl, font=("Courier New", 11),
                     bg=CARD, fg=TEXT).grid(row=row_i, column=0, sticky="w", pady=4)
            var = tk.StringVar()
            setattr(self, var_name, var)
            tk.Entry(af, textvariable=var,
                     font=("Courier New", 12),
                     bg=CARD2, fg=color, insertbackground=color,
                     relief="flat", width=17).grid(row=row_i, column=1,
                                                    padx=(10,0), ipady=5)

        bf = tk.Frame(ac, bg=CARD)
        bf.pack(fill="x", padx=14, pady=(0,12))
        self._mk_btn(bf, "Add Caller",  self._add_caller,  ACCENT).pack(side="left")
        self._mk_btn(bf, "Clear All",   self._clear_all,   RED   ).pack(side="right")

        # Queue list
        lc = self._section(parent, "CALLER QUEUE", top=10)
        lf = tk.Frame(lc, bg=CARD)
        lf.pack(fill="both", padx=14, pady=10)

        self._apply_tree_style()
        cols = ("Name", "Burst Time")
        self.queue_tree = ttk.Treeview(lf, columns=cols, show="headings", height=5)
        for c in cols:
            self.queue_tree.heading(c, text=c)
            self.queue_tree.column(c, width=125, anchor="center")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.queue_tree.yview)
        self.queue_tree.configure(yscrollcommand=sb.set)
        self.queue_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        df = tk.Frame(lc, bg=CARD)
        df.pack(fill="x", padx=14, pady=(0,10))
        self._mk_btn(df, "Remove Selected", self._remove_caller, MUTED).pack(side="left")

        # Run + Save buttons — side by side so Save is always visible
        tk.Frame(parent, bg=BG, height=10).pack()
        btn_row = tk.Frame(parent, bg=BG)
        btn_row.pack(fill="x")

        tk.Button(btn_row, text="RUN",
                  font=("Courier New", 12, "bold"),
                  bg=GREEN, fg="#071a10",
                  activebackground="#04c48a",
                  relief="flat", cursor="hand2",
                  command=self._run_simulation).pack(side="left", fill="x",
                                                     expand=True, ipady=11)

        tk.Frame(btn_row, bg=BG, width=6).pack(side="left")

        tk.Button(btn_row, text="SAVE",
                  font=("Courier New", 12, "bold"),
                  bg=ACCENT2, fg="#052018",
                  activebackground="#00b090",
                  relief="flat", cursor="hand2",
                  command=self._save_as).pack(side="left", fill="x",
                                              expand=True, ipady=11)

    # -------- RIGHT PANEL --------
    def _build_right(self, parent):
        s = ttk.Style()
        s.theme_use("default")
        s.configure("Dark.TNotebook",
                    background=BG, borderwidth=0)
        s.configure("Dark.TNotebook.Tab",
                    background=CARD, foreground=MUTED,
                    font=("Courier New", 10, "bold"),
                    padding=[18, 8])
        s.map("Dark.TNotebook.Tab",
              background=[("selected", ACCENT)],
              foreground=[("selected", WHITE)])

        nb = ttk.Notebook(parent, style="Dark.TNotebook")
        nb.pack(fill="both", expand=True)

        t1 = tk.Frame(nb, bg=BG); nb.add(t1, text="  Execution Log  ")
        t2 = tk.Frame(nb, bg=BG); nb.add(t2, text="  Results Table  ")
        t3 = tk.Frame(nb, bg=BG); nb.add(t3, text="  Gantt Chart    ")

        self._tab_log(t1)
        self._tab_results(t2)
        self._tab_gantt(t3)

    def _tab_log(self, parent):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill="both", expand=True, padx=8, pady=8)
        self.log_box = tk.Text(f, bg="#080b12", fg=ACCENT2,
                               font=("Courier New", 11),
                               relief="flat", bd=0,
                               insertbackground=WHITE,
                               selectbackground=ACCENT,
                               wrap="none")
        vsb = ttk.Scrollbar(f, orient="vertical",   command=self.log_box.yview)
        hsb = ttk.Scrollbar(f, orient="horizontal", command=self.log_box.xview)
        self.log_box.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right",  fill="y")
        hsb.pack(side="bottom", fill="x")
        self.log_box.pack(fill="both", expand=True)
        self._log_write("  Simulation log will appear here...\n")

    def _tab_results(self, parent):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill="both", expand=True, padx=8, pady=8)
        cols = ("Caller", "Burst", "Completion", "Turnaround", "Waiting")
        self.res_tree = ttk.Treeview(f, columns=cols, show="headings")
        ws   = [170, 80, 110, 110, 90]
        for c, w in zip(cols, ws):
            self.res_tree.heading(c, text=c)
            self.res_tree.column(c, width=w, anchor="center")
        sb = ttk.Scrollbar(f, orient="vertical", command=self.res_tree.yview)
        self.res_tree.configure(yscrollcommand=sb.set)
        self.res_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.avg_lbl = tk.Label(parent, text="",
                                font=("Courier New", 11),
                                bg=BG, fg=AMBER)
        self.avg_lbl.pack(pady=6)

    def _tab_gantt(self, parent):
        self.gantt_cv = tk.Canvas(parent, bg="#080b12",
                                  highlightthickness=0)
        hsb = ttk.Scrollbar(parent, orient="horizontal",
                             command=self.gantt_cv.xview)
        self.gantt_cv.configure(xscrollcommand=hsb.set)
        hsb.pack(side="bottom", fill="x")
        self.gantt_cv.pack(fill="both", expand=True, padx=8, pady=8)

    # -------- HELPERS --------
    def _mk_btn(self, parent, text, cmd, color):
        return tk.Button(parent, text=text,
                         font=("Courier New", 10, "bold"),
                         bg=color, fg=WHITE,
                         activebackground=color,
                         relief="flat", cursor="hand2",
                         padx=10, pady=5, command=cmd)

    def _apply_tree_style(self):
        s = ttk.Style()
        s.configure("Treeview",
                    background=CARD2, foreground=TEXT,
                    fieldbackground=CARD2,
                    font=("Courier New", 11),
                    rowheight=28)
        s.configure("Treeview.Heading",
                    background=CARD, foreground=MUTED,
                    font=("Courier New", 10, "bold"),
                    relief="flat")
        s.map("Treeview", background=[("selected", ACCENT)])

    def _log_write(self, msg, clear=False):
        self.log_box.configure(state="normal")
        if clear:
            self.log_box.delete("1.0", "end")
        self.log_box.insert("end", msg + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    # -------- ACTIONS --------
    def _add_caller(self):
        name  = self.name_var.get().strip()
        burst = self.burst_var.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter the caller's name!")
            return
        if not burst.isdigit() or int(burst) <= 0:
            messagebox.showwarning("Input Error", "Burst time must be a positive number!")
            return
        if len(self.callers_data) >= 10:
            messagebox.showwarning("Limit", "Maximum 10 callers allowed!")
            return
        self.callers_data.append((name, int(burst)))
        self.queue_tree.insert("", "end", values=(name, burst))
        self.name_var.set("")
        self.burst_var.set("")

    def _remove_caller(self):
        sel = self.queue_tree.selection()
        if not sel:
            return
        idx = self.queue_tree.index(sel[0])
        self.queue_tree.delete(sel[0])
        self.callers_data.pop(idx)

    def _clear_all(self):
        self.queue_tree.delete(*self.queue_tree.get_children())
        self.callers_data.clear()

    def _run_simulation(self):
        if not self.callers_data:
            messagebox.showwarning("No Callers", "Please add callers first!")
            return
        q = self.quantum_var.get().strip()
        if not q.isdigit() or int(q) <= 0:
            messagebox.showwarning("Quantum Error", "Time quantum must be a positive number!")
            return
        quantum = int(q)

        callers = [Caller(n, b) for n, b in self.callers_data]
        gantt, log_lines = round_robin(callers, quantum)

        total_wt  = sum(c.waiting_time    for c in callers)
        total_tat = sum(c.turnaround_time for c in callers)
        avg_wt    = total_wt  / len(callers)
        avg_tat   = total_tat / len(callers)

        self.sim_count += 1
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        self.last_results = {
            "callers"  : callers,
            "quantum"  : quantum,
            "gantt"    : gantt,
            "log"      : log_lines,
            "avg_wt"   : avg_wt,
            "avg_tat"  : avg_tat,
            "timestamp": timestamp,
            "sim_num"  : self.sim_count,
        }

        # --- Log tab ---
        sep = "=" * 58
        self._log_write("", clear=True)
        self._log_write(f"  {sep}")
        self._log_write(f"  SIMULATION #{self.sim_count}  |  {timestamp}")
        self._log_write(f"  Time Quantum : {quantum}")
        self._log_write(f"  {sep}")
        for line in log_lines:
            self._log_write(line)
        self._log_write(f"  {sep}")
        self._log_write(f"  Avg Waiting Time    : {avg_wt:.2f}")
        self._log_write(f"  Avg Turnaround Time : {avg_tat:.2f}")

        # --- Results tab ---
        for row in self.res_tree.get_children():
            self.res_tree.delete(row)
        palette = [ACCENT, ACCENT2, AMBER, RED, GREEN,
                   "#f72585", "#4cc9f0", "#a29bfe"]
        for i, c in enumerate(callers):
            tag = f"r{i}"
            self.res_tree.insert("", "end", tags=(tag,),
                                 values=(c.name, c.burst_time,
                                         c.completion_time,
                                         c.turnaround_time,
                                         c.waiting_time))
            self.res_tree.tag_configure(tag, foreground=palette[i % len(palette)])
        self.avg_lbl.config(
            text=f"  Avg Waiting Time: {avg_wt:.2f}   |   Avg Turnaround Time: {avg_tat:.2f}"
        )

        # --- Gantt tab ---
        self._draw_gantt(gantt)

        messagebox.showinfo("Simulation Complete!",
                            f"Simulation #{self.sim_count} complete!\n\n"
                            f"Avg Waiting Time    : {avg_wt:.2f}\n"
                            f"Avg Turnaround Time : {avg_tat:.2f}\n\n"
                            f"Use 'Save Results As...' to save the file.")

    def _draw_gantt(self, gantt):
        cv = self.gantt_cv
        cv.delete("all")
        if not gantt:
            return

        palette = [ACCENT, ACCENT2, AMBER, RED, GREEN,
                   "#f72585", "#4cc9f0", "#7bed9f", "#a29bfe", "#ffa502"]
        caller_color = {}
        ci = 0

        x0      = 50
        y_top   = 55
        h       = 50
        px      = 40   # pixels per time unit

        cv.create_text(x0, 25, text="Gantt Chart",
                       fill=TEXT, font=("Courier New", 12, "bold"), anchor="w")

        for name, start, end in gantt:
            if name not in caller_color:
                caller_color[name] = palette[ci % len(palette)]
                ci += 1
            col = caller_color[name]
            x1  = x0 + start * px
            x2  = x0 + end   * px
            mx  = (x1 + x2) / 2

            cv.create_rectangle(x1, y_top, x2, y_top + h,
                                 fill=col, outline=BG, width=2)
            cv.create_text(mx, y_top + h/2, text=name,
                           fill=WHITE, font=("Courier New", 9, "bold"))
            cv.create_text(x1, y_top + h + 18, text=str(start),
                           fill=MUTED, font=("Courier New", 9))

        last_end = gantt[-1][2]
        cv.create_text(x0 + last_end * px, y_top + h + 18,
                       text=str(last_end), fill=MUTED,
                       font=("Courier New", 9))

        # Legend
        lx = x0
        ly = y_top + h + 44
        cv.create_text(lx, ly, text="Legend:",
                       fill=MUTED, font=("Courier New", 9), anchor="w")
        lx += 60
        for name, col in caller_color.items():
            cv.create_rectangle(lx, ly-7, lx+12, ly+7, fill=col, outline="")
            cv.create_text(lx+18, ly, text=name,
                           fill=TEXT, font=("Courier New", 9), anchor="w")
            lx += len(name)*7 + 38

        total_w = x0 + last_end * px + 80
        cv.configure(scrollregion=(0, 0, total_w, 160))

    # -------- SAVE (WSL compatible - direct save, no dialog) --------
    def _save_as(self):
        import os
        if not self.last_results:
            messagebox.showwarning("No Results", "Please run the simulation first!")
            return

        r   = self.last_results
        now = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = f"simulation_{r['sim_num']}_{now}.txt"

        # Save in same folder as script — always works in WSL
        script_dir = os.path.dirname(os.path.abspath(__file__))
        full_path  = os.path.join(script_dir, fname)

        try:
            self._write_file(full_path, r)
            messagebox.showinfo(
                "Saved!",
                f"File saved successfully!\n\n"
                f"Filename : {fname}\n\n"
                f"Location :\n{full_path}"
            )
        except Exception as e:
            messagebox.showerror("Save Error", f"Could not save file:\n{e}")

    def _write_file(self, path, r):
        sep = "=" * 64
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"{sep}\n")
            f.write(f"     CALL CENTER SIMULATION RESULTS\n")
            f.write(f"     Round Robin Scheduling Algorithm\n")
            f.write(f"     Jinnah University for Women - Karachi\n")
            f.write(f"{sep}\n\n")
            f.write(f"Simulation No : {r['sim_num']}\n")
            f.write(f"Date & Time   : {r['timestamp']}\n")
            f.write(f"Time Quantum  : {r['quantum']}\n\n")

            f.write(f"{'CALLER NAME':<20} {'BURST':>6} {'COMPLETION':>12}"
                    f" {'TURNAROUND':>12} {'WAITING':>10}\n")
            f.write("-" * 64 + "\n")
            for c in r["callers"]:
                f.write(f"{c.name:<20} {c.burst_time:>6} {c.completion_time:>12}"
                        f" {c.turnaround_time:>12} {c.waiting_time:>10}\n")

            f.write(f"\nAverage Waiting Time    : {r['avg_wt']:.2f}\n")
            f.write(f"Average Turnaround Time : {r['avg_tat']:.2f}\n\n")

            f.write("--- STEP-BY-STEP EXECUTION LOG ---\n")
            for line in r["log"]:
                f.write(line + "\n")

            f.write("\n--- GANTT CHART (text) ---\n|")
            for name, _, _ in r["gantt"]:
                f.write(f" {name:<10} |")
            f.write("\n")
            f.write(f"{r['gantt'][0][1]:<13}")
            for _, _, end in r["gantt"]:
                f.write(f"{end:<13}")
            f.write(f"\n\n{sep}\n")

# ===================== ENTRY POINT =====================
if __name__ == "__main__":
    root = tk.Tk()
    app  = CallCenterApp(root)
    root.mainloop()
